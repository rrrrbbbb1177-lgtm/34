# 🚚 Delivery Report Organizer

A single-purpose tool that reorganizes delivery report PDFs by store — **without modifying any original data**.

## Quick Start

```bash
npm install
npm run dev
```

Then open: [http://localhost:3000](http://localhost:3000)

## What it does

1. **Upload** a delivery report PDF
2. **Process** — extracts rows, groups by store, sorts by notes
3. **Download** the clean organized PDF

## Rules (enforced)

| Rule | Status |
|------|--------|
| No row deleted | ✅ Enforced |
| No row added | ✅ Enforced |
| No value changed | ✅ Enforced |
| Row count validation | ✅ Before every export |
| Reordering only | ✅ |

## Expected PDF Format

Each line should have these fields (tab or multi-space separated):

```
receipt   store   amount   status   notes   date
```

## Project Structure

```
delivery-organizer/
├── src/
│   ├── server.js         Express server
│   ├── parser.js         PDF text → row objects
│   ├── sorter.js         Group by store, sort by notes
│   ├── pdfGenerator.js   Generate output PDF
│   └── routes/
│       └── upload.js     POST /api/process endpoint
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── uploads/              Temporary uploads (auto-cleaned)
├── outputs/              Temporary outputs (auto-cleaned)
└── package.json
```
