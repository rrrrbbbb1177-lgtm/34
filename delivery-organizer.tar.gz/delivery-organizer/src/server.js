'use strict';

const express = require('express');
const path    = require('path');
const fs      = require('fs');

const uploadRoutes = require('./routes/upload');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Ensure required directories exist ────────────────────────────────────────
['uploads', 'outputs'].forEach(dir => {
  const p = path.join(__dirname, '..', dir);
  fs.mkdirSync(p, { recursive: true });
});

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/api', uploadRoutes);

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok' }));

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n  🚚  Delivery Organizer running at http://localhost:${PORT}\n`);
});

module.exports = app;
